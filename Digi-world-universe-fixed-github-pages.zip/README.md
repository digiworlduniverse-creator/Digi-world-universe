# Digi World Universe — GitHub Pages deployment

Domain: https://digiuniverse.world

## Fixed in this deployment
- GitHub Pages compatible static form (no Netlify-only `data-netlify` dependency).
- Responsive mobile navigation instead of hiding the navigation completely.
- Mobile layout fixes for hero, cards, About section, contact area and floating WhatsApp button.
- Reduced-motion accessibility support.
- SEO: canonical URL, Open Graph URL, Twitter metadata, theme color and JSON-LD ProfessionalService schema.
- Added `CNAME`, `robots.txt`, `sitemap.xml`, and a simple `404.html`.
- Video preload changed from `auto` to `metadata` to reduce initial page load pressure.

## Assets still required
The original HTML references the supplied brand/logo and video/package files. Keep these filenames in the repository root to preserve the exact visuals:
- `DiGi Logo (1).jpg`
- `digi-world-promo.mp4.mp4`
- `Boss IO.mp4`
- `Boss.mp4`
- `Package 1.png`
- `Package 2.png`
- `package 3.png`
- `package 4.png`

The source HTML/design itself has not been redesigned.
