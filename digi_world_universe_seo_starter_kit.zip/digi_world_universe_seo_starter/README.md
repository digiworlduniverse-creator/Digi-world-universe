# DiGi World Universe — SEO starter kit

This package is a safe implementation draft for https://digiuniverse.world/.
It does NOT modify the live website. Review the current site code and merge only the applicable snippets.

## Verified public details
- Brand: DiGi World Universe
- Website: https://digiuniverse.world/
- Public phone shown on homepage: +91 73047 84432
- Public email shown on homepage: contact@digiworlduniverse.com
- Public location wording: Mira Road, Mumbai

Verify the phone/email and the exact legal business name before publishing structured data.
Do not invent a full street address, coordinates, opening hours, ratings, or review counts.

## Files
- `snippets/homepage-head.html`: suggested title, description, canonical, Open Graph and Organization/LocalBusiness JSON-LD draft.
- `snippets/homepage-content-outline.md`: suggested homepage copy additions that preserve the existing visual style.
- `snippets/robots.txt`: conservative robots template; confirm your hosting setup before using.
- `snippets/sitemap.xml`: minimal homepage sitemap template; add only real, canonical, indexable URLs.
- `service-page-plan.md`: page map and content brief.
- `search-console-checklist.md`: exact steps to collect ranking baseline and validate after deployment.

## Before publishing
1. Check whether the current site already has a title, canonical, robots directives, sitemap, and structured data. Do not duplicate them.
2. Keep the existing design, logo, video, navigation, and brand styling.
3. Replace placeholder or draft content only after checking it against the business's actual services and proof.
4. Use only URLs that return HTTP 200 and are intended to be indexed.
5. Submit the sitemap in Search Console after it is deployed.
6. Do not expect a guaranteed ranking or a fixed time to rank.
