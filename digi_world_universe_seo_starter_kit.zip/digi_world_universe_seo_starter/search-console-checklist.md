# Search Console implementation checklist

## Baseline
1. Open https://search.google.com/search-console/
2. Select the verified `digiuniverse.world` property.
3. Performance → Search results → choose last 3 months.
4. Enable clicks, impressions, CTR, average position.
5. Export the Queries and Pages tables (CSV or Google Sheets).
6. Export or capture Page indexing status and Sitemaps status.
7. In Performance, segment India and compare mobile vs desktop where useful.

## Fix and validate
- Inspect homepage and every important service URL with URL Inspection.
- Confirm indexing status, Google-selected canonical, crawl allowed and rendered content.
- Check Manual actions and Security issues in the Overview.
- After a deploy, test the canonical URL and sitemap in a browser.
- Submit the sitemap in Search Console only after verifying it lists real canonical URLs.
- Use URL Inspection's request indexing for a small number of important changed/new pages after fixes.

## Opportunity triage
- High impressions + relevant query + low CTR: assess title/snippet relevance and search intent.
- Relevant query with average position roughly 8–25: assess content depth, intent match, internal links and competing results.
- Important URL not indexed: inspect the specific exclusion reason before requesting indexing.
- Branded vs non-branded query split: use it to understand whether growth comes from brand awareness or discovery.
- Track clicks, qualified enquiries and conversions—not position alone.
